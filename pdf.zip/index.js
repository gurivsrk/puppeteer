const puppeteer = require('puppeteer');


// screenshot 
// (async () => {
//   const browser = await puppeteer.launch();
//   const page = await browser.newPage();
//   await page.goto('https://vsrkcapital.com');
//   await page.screenshot({path: 'screenshot/screenshot.png'});

//   await browser.close();
// })();


// create a PDF
(async () => {
    const browser = await puppeteer.launch();
    const page = await browser.newPage();
    await page.goto('https://vsrkcapital.com', {
      waitUntil: 'networkidle2',
    });
    await page.pdf({path: 'pdf/hn.pdf', format: 'a4'});
  
    await browser.close();
  })();